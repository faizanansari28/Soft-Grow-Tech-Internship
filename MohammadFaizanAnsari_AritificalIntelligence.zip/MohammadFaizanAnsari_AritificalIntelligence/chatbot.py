"""
chatbot.py
----------
Console-based AI Customer Support Chatbot.

Loads the trained TF-IDF + Logistic Regression model (model.pkl) produced
by train_model.py, then runs an interactive loop:

    1. Read user input from the console
    2. Preprocess it the same way the training data was processed
    3. Vectorize it with the saved TF-IDF vectorizer
    4. Predict the most likely intent + confidence score
    5. If confidence is high enough, reply with a response from that
       intent. Otherwise, return a fallback message.
    6. Log the conversation to chat_log.txt for record-keeping.

Run:
    python chatbot.py
"""

import json
import pickle
import random
import re
import string
import os
os.system("cls")
from datetime import datetime

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize

CONFIDENCE_THRESHOLD = 0.18  # below this, the bot admits it isn't sure
# Note: with a small training set spread across 13 intents, predicted
# probabilities are naturally lower than in large real-world datasets.
# Add more patterns per intent in intents.json and retrain to raise
# confidence and push this threshold back up.
MODEL_PATH = "model.pkl"
LOG_PATH = "chat_log.txt"


def ensure_nltk_data():
    required = [
        ("tokenizers/punkt", "punkt"),
        ("tokenizers/punkt_tab", "punkt_tab"),
        ("corpora/stopwords", "stopwords"),
        ("corpora/wordnet", "wordnet"),
    ]
    for path, name in required:
        try:
            nltk.data.find(path)
        except LookupError:
            nltk.download(name, quiet=True)


ensure_nltk_data()
lemmatizer = WordNetLemmatizer()
STOPWORDS = set(stopwords.words("english"))
KEEP_WORDS = {"not", "no", "can", "cannot", "isn't", "won't"}
STOPWORDS = STOPWORDS - KEEP_WORDS


def preprocess(text: str) -> str:
    """Same cleaning pipeline used during training, applied to user input."""
    text = text.lower()
    text = re.sub(r"[^\w\s']", " ", text)
    tokens = word_tokenize(text)
    cleaned = [
        lemmatizer.lemmatize(tok)
        for tok in tokens
        if tok not in STOPWORDS and tok not in string.punctuation
    ]
    return " ".join(cleaned)


class SupportChatbot:
    def __init__(self, model_path=MODEL_PATH):
        with open(model_path, "rb") as f:
            saved = pickle.load(f)
        self.model = saved["model"]
        self.vectorizer = saved["vectorizer"]
        self.intents_data = saved["intents"]

        # Map intent tag -> list of possible responses, for fast lookup
        self.responses_by_tag = {
            intent["tag"]: intent["responses"]
            for intent in self.intents_data["intents"]
        }

    def predict_intent(self, user_text: str):
        """
        Returns (predicted_tag, confidence) for a raw user message.
        Confidence is the model's predicted probability for the top class.
        """
        cleaned = preprocess(user_text)
        if cleaned.strip() == "":
            return "fallback", 0.0

        vec = self.vectorizer.transform([cleaned])
        probs = self.model.predict_proba(vec)[0]
        classes = self.model.classes_

        best_idx = probs.argmax()
        best_tag = classes[best_idx]
        confidence = probs[best_idx]
        return best_tag, confidence

    def get_response(self, user_text: str):
        tag, confidence = self.predict_intent(user_text)

        if confidence < CONFIDENCE_THRESHOLD:
            tag = "fallback"

        responses = self.responses_by_tag.get(tag, self.responses_by_tag["fallback"])
        reply = random.choice(responses)
        return reply, tag, confidence


def log_interaction(user_text, tag, confidence, reply):
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(
            f"[{timestamp}] USER: {user_text}\n"
            f"[{timestamp}] INTENT: {tag} (confidence={confidence:.2f})\n"
            f"[{timestamp}] BOT: {reply}\n\n"
        )


def main():
    print("=" * 60)
    print(" AI Customer Support Chatbot (type 'quit' to exit) ")
    print("=" * 60)

    try:
        bot = SupportChatbot()
    except FileNotFoundError:
        print(
            "\nNo trained model found (model.pkl missing).\n"
            "Please run 'python train_model.py' first to train the model."
        )
        return

    print("Bot: Hello! Welcome to support. How can I help you today?\n")

    while True:
        try:
            user_text = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBot: Goodbye!")
            break

        if not user_text:
            continue

        reply, tag, confidence = bot.get_response(user_text)
        print(f"Bot: {reply}")

        # Show intent + confidence for demo/debugging purposes.
        # (Useful to show during your internship presentation/demo.)
        print(f"     [debug: intent={tag}, confidence={confidence:.2f}]\n")

        log_interaction(user_text, tag, confidence, reply)

        if tag == "goodbye":
            break

        if user_text.lower() in ("quit", "exit"):
            print("Bot: Goodbye!")
            break


if __name__ == "__main__":
    main()
