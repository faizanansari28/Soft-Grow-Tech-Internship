"""
train_model.py
----------------
Trains a Machine Learning model to classify user messages into "intents"
(e.g. order_status, refund_request, complaint, greeting...) for the
AI Customer Support Chatbot.

Pipeline:
    raw text -> preprocessing (lowercase, tokenize, remove stopwords, lemmatize)
             -> TF-IDF vectorization
             -> Logistic Regression classifier

The trained model + vectorizer are saved to disk (model.pkl) so that
chatbot.py can load them instantly without retraining every time.

Run this once before using chatbot.py:
    python train_model.py
"""

import json
import pickle
import re
import string

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score


# ----------------------------------------------------------------------
# 1. Make sure required NLTK data is available (auto-downloads once)
# ----------------------------------------------------------------------
def ensure_nltk_data():
    required = [
        ("tokenizers/punkt", "punkt"),
        ("tokenizers/punkt_tab", "punkt_tab"),
        ("corpora/stopwords", "stopwords"),
        ("corpora/wordnet", "wordnet"),
    ]
    for path, name in required:
        try:
            nltk.data.find(path)
        except LookupError:
            print(f"Downloading NLTK resource: {name} ...")
            nltk.download(name, quiet=True)


ensure_nltk_data()

lemmatizer = WordNetLemmatizer()
STOPWORDS = set(stopwords.words("english"))
# Keep a few negation-related / support-relevant words even though they're
# normally treated as stopwords, since they can carry meaning in support chat.
KEEP_WORDS = {"not", "no", "can", "cannot", "isn't", "won't"}
STOPWORDS = STOPWORDS - KEEP_WORDS


def preprocess(text: str) -> str:
    """
    Cleans and normalizes raw text for the model:
      1. Lowercase
      2. Remove punctuation
      3. Tokenize
      4. Remove stopwords
      5. Lemmatize (reduce words to their base/dictionary form)
    Returns a single cleaned string ready for TF-IDF vectorization.
    """
    text = text.lower()
    text = re.sub(r"[^\w\s']", " ", text)  # strip punctuation except apostrophes
    tokens = word_tokenize(text)
    cleaned_tokens = [
        lemmatizer.lemmatize(tok)
        for tok in tokens
        if tok not in STOPWORDS and tok not in string.punctuation
    ]
    return " ".join(cleaned_tokens)


def load_training_data(path="intents.json"):
    """
    Reads intents.json and flattens it into parallel lists of
    (cleaned_pattern, intent_tag) pairs for supervised training.
    """
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    texts, labels = [], []
    for intent in data["intents"]:
        tag = intent["tag"]
        for pattern in intent.get("patterns", []):
            texts.append(preprocess(pattern))
            labels.append(tag)
    return texts, labels, data


def main():
    print("Loading and preprocessing training data...")
    texts, labels, raw_data = load_training_data()
    print(f"Loaded {len(texts)} training examples across "
          f"{len(set(labels))} intents.")

    # ------------------------------------------------------------------
    # 2. Vectorize text using TF-IDF (Term Frequency - Inverse Document
    #    Frequency). This turns text into numeric feature vectors that
    #    reflect how important each word is within the dataset.
    # ------------------------------------------------------------------
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
    X = vectorizer.fit_transform(texts)
    y = labels

    # ------------------------------------------------------------------
    # 3. Train / test split for an honest accuracy estimate.
    #    (Dataset is small, so this is just a sanity check, not a
    #    rigorous benchmark.)
    # ------------------------------------------------------------------
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
    except ValueError:
        # Falls back to a non-stratified split if a class has too few samples
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )

    # ------------------------------------------------------------------
    # 4. Train a Logistic Regression classifier on top of the TF-IDF
    #    features. Logistic Regression works well for small text
    #    classification tasks and gives interpretable probabilities,
    #    which we use later for the confidence threshold / fallback.
    # ------------------------------------------------------------------
    model = LogisticRegression(max_iter=1000)
    model.fit(X_train, y_train)

    # Evaluate
    if len(set(y_test)) > 0:
        y_pred = model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        print(f"\nValidation accuracy: {acc:.2f}")
        print("\nClassification report:")
        print(classification_report(y_test, y_pred, zero_division=0))

    # Retrain on the FULL dataset before saving, so the deployed model
    # uses every available example (the held-out split above was only
    # for evaluation).
    final_model = LogisticRegression(max_iter=1000)
    final_model.fit(X, y)

    # ------------------------------------------------------------------
    # 5. Persist the trained model + vectorizer + raw intents data
    # ------------------------------------------------------------------
    with open("model.pkl", "wb") as f:
        pickle.dump(
            {
                "model": final_model,
                "vectorizer": vectorizer,
                "intents": raw_data,
            },
            f,
        )

    print("\nModel trained and saved to model.pkl")


if __name__ == "__main__":
    main()
