# AI Chatbot for Customer Support

A console-based AI chatbot built with **Machine Learning** and **Natural Language Processing (NLP)** that classifies user messages into support intents (order status, refunds, complaints, shipping, payments, account help, etc.) and replies with relevant, automated responses.

## How it works (AI concepts used)

1. **Dataset (`intents.json`)** — A labeled dataset of example customer messages ("patterns") grouped under intent categories ("tags"), each with a set of possible bot responses. This is the chatbot's knowledge base.

2. **Text preprocessing (NLP)** — Every message is:
   - Lowercased and stripped of punctuation
   - Tokenized into words (`nltk.word_tokenize`)
   - Cleared of stopwords ("the", "is", "a", ...)
   - Lemmatized (reduced to base form, e.g. "shipping" → "ship")

3. **Feature extraction — TF-IDF** — Cleaned text is converted into numeric vectors using `TfidfVectorizer`, which weighs words by how informative they are across the dataset (unigrams + bigrams).

4. **Classification model** — A `LogisticRegression` classifier (scikit-learn) is trained on the TF-IDF vectors to predict which intent a new message belongs to, along with a confidence score (predicted probability).

5. **Response generation** — Once an intent is predicted, the bot picks a random response from that intent's response list. If the model's confidence is below a threshold, it falls back to a "I'm not sure I understand" message instead of guessing — this is what makes it more reliable than basic keyword-matching bots.

6. **Logging** — Every exchange is appended to `chat_log.txt` with the predicted intent and confidence, useful for showing how the system reasons during a demo or presentation.

## Project structure

```
chatbot_project/
├── intents.json        # Training data: patterns + responses per intent
├── train_model.py      # Preprocesses data, trains the ML model, saves model.pkl
├── chatbot.py           # Console chat interface that uses the trained model
├── requirements.txt     # Python dependencies
├── model.pkl             # (generated) trained model + vectorizer
└── chat_log.txt          # (generated) conversation log
```

## Setup & usage

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Train the model (creates model.pkl)
python train_model.py

# 3. Run the chatbot
python chatbot.py
```

Type messages like:
- "where is my order"
- "i want a refund"
- "my card got declined"
- "talk to a human"

Type `bye`, `quit`, or `exit` to end the chat.

## Extending this project

- **Add more intents/patterns** in `intents.json` (more examples per intent = higher confidence and accuracy), then re-run `train_model.py`.
- **Swap the model**: try `MultinomialNB`, `SVC`, or a neural network (e.g. a small Keras/PyTorch classifier) in `train_model.py` and compare accuracy.
- **Add a real database lookup**: instead of asking the user for an order ID and stopping there, connect to a mock orders database to actually return order status.
- **Upgrade NLP**: swap TF-IDF for pretrained embeddings (e.g. `sentence-transformers`) for better semantic understanding of paraphrased questions.
- **Add a web UI**: wrap `SupportChatbot` from `chatbot.py` in a Flask/FastAPI app with a simple HTML chat widget.

## Notes for the demo/presentation

- The console output shows `[debug: intent=..., confidence=...]` after each reply — useful to demonstrate that this is a real ML classifier making a prediction, not hardcoded if/else rules.
- `chat_log.txt` is a good artifact to include in your submission as evidence of testing.
- The dataset is intentionally small for a learning project; if asked about limitations, mention that accuracy and confidence scale with the amount and diversity of training data.
